package hello;

public class HelloMessage {

    private String name;
    
    public String getName() {
        return name;
    }

}
